package assignment1v2;

/**
 * Represents the scheduling contract for events within the simulation.
 * This interface defines a core functionality for any class that will handle
 * the scheduling of events. Implementing classes are expected to manage the
 * timing and execution order of simulation events according to their specific
 * scheduling strategy or mechanism.
 * 
 * Classes implementing this interface should ensure that events are processed
 * in a manner consistent with the simulation's rules and requirements.
 * 
 * @author Mohammad Minhaz Uddin
 */
public interface IScheduler {

    /**
     * Schedules an event to be processed within the simulation environment.
     * This method is responsible for adding the event to the queue or list
     * that manages when and how events are executed based on the simulation
     * timeline.
     * 
     * @param e The event to be scheduled. This event must implement the process method
     *          defining its behavior when it occurs within the simulation's timeline.
     */
    void schedule(Event e);
}
