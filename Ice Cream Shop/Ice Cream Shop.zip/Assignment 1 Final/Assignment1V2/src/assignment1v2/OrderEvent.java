
package assignment1v2;

import java.util.Random;

/**
 * Represents an event where a customer group places an order in the shop.
 * This class handles the logic of processing an order and subsequently scheduling a
 * leave event based on a random duration that the group stays after placing their order.
 * This simulates the variable time groups may spend in the shop after receiving their service.
 * 
 * @author Mohammad Minhaz Uddin
 */
public class OrderEvent extends Event {
    private CustomerGroup group; // The customer group that is placing the order

    /**
     * Constructs an OrderEvent at a specific time for a given customer group.
     * 
     * @param time The simulation time at which the order is placed.
     * @param group The customer group placing the order.
     */
    public OrderEvent(int time, CustomerGroup group) {
        super(time);
        this.group = group;
    }

    /**
     * Processes the order by serving the group and scheduling their departure from the shop.
     * The departure time is determined randomly to simulate varying stay durations after ordering.
     * 
     * @param sm The shop model that manages the state and interactions of customer groups in the shop.
     * @param s The simulator that manages the scheduling of events.
     */
    @Override
    public void process(ShopModel sm, Simulator s) {
        // Serving the order to the group at the current time
        sm.serveOrder(getTime(), group);

        // Accessing the shared random generator
        Random random = Event.getGenerator();

        // Determining a random leave time between 5 and 12 time units after the order
        int leaveTime = getTime() + random.nextInt(8) + 5; // Random time within 5 to 12 units

        // Scheduling the leave event for the group
        s.schedule(new LeaveEvent(leaveTime, group));
    }
}
