package assignment1v2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.PriorityQueue;

class Simulator {
    private ShopModel model;
    private int clock;
    private PriorityQueue<Event> events;

    public Simulator(ShopModel model) {
        this.model = model;
        events = new PriorityQueue<>((e1, e2) -> Integer.compare(e1.getTime(), e2.getTime()));
    }

    public void initialize(List<Event> initialEvents) {
        events.addAll(initialEvents);
    }

    public void run(int stopTime) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("statistics.txt"))) {
            while (!events.isEmpty() && clock < stopTime) {
                Event currentEvent = events.poll();
                clock = currentEvent.getTime();
                currentEvent.process(model, this);
                writer.flush();  // Ensure data is written to the file in real time
            }
            // After simulation ends, write the summary statistics and logs
            writeStatistics(writer);
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }
    }

    private void writeStatistics(BufferedWriter writer) throws IOException {
        writer.write("Simulation Statistics:\n");
        writer.write("Customers Served: " + model.getNumServed() + "\n");
        writer.write("Lost Business: " + model.getLostBusiness() + "\n");
        writer.write("\nHistory/Log of Customer Groups:\n");
        for (CustomerGroup group : model.getHistoryLog()) {
            writer.write(group.toString() + "\n");
        }
        writer.write("\nGroups in the shop:\n");
        for (CustomerGroup group : model.getGroupsInShop()) {
            writer.write(group.toString() + "\n");
        }
    }

    public void schedule(Event event) {
        events.add(event);
    }
}
