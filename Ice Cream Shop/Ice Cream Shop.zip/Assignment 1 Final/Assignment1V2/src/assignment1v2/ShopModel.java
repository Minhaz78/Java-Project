package assignment1v2;

import java.util.ArrayList;
import java.util.List;

class ShopModel {
    private List<CustomerGroup> groupsInShop;
    private List<CustomerGroup> historyLog;
    private int nextIdentifier;
    private int numSeats;
    private int lostBusiness;
    private int numServed;

    public ShopModel(int numSeats) {
        this.numSeats = numSeats;
        groupsInShop = new ArrayList<>();
        historyLog = new ArrayList<>();
        nextIdentifier = 0;
        lostBusiness = 0;
        numServed = 0;
    }

    public int getNextId() {
        return nextIdentifier++;
    }

    public void addGroup(CustomerGroup group) {
        if (canSeat(group.getArrivalTime(), group)) {
            groupsInShop.add(group);
            numSeats -= group.getNumPeople(); // Deduct the number of seats occupied by the group
        }
    }

    public void leave(int time, CustomerGroup group) {
        groupsInShop.remove(group);
        numSeats += group.getNumPeople(); // Free the seats occupied by the group
        System.out.println("t = " + time + ": Group " + group.getGroupId() + " leaves");
    }

    public boolean canSeat(int arrivalTime, CustomerGroup group) {
        return numSeats >= group.getNumPeople();
    }

    public void serveOrder(int time, CustomerGroup group) {
        System.out.println("t = " + time + ": Order served for Group " + group.getGroupId());
        numServed += group.getNumPeople(); // Increment by the number of people in the group
    }

    public void incrementLostBusiness(int numPeople) {
        lostBusiness += numPeople;
    }

    public int getLostBusiness() {
        return lostBusiness;
    }

    public void logGroup(CustomerGroup group) {
        historyLog.add(group);
    }

    public List<CustomerGroup> getGroupsInShop() {
        return groupsInShop;
    }

    public List<CustomerGroup> getHistoryLog() {
        return historyLog;
    }

    public int getNumServed() {
        return numServed;
    }
}
