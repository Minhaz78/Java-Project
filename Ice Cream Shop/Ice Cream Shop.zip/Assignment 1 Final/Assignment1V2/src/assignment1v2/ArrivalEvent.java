package assignment1v2;

import java.util.Random;

/**
 * Represents an arrival event in the simulation where a new customer group arrives at the shop.
 * This class is responsible for processing the arrival of groups, checking if they can be seated,
 * and scheduling further events such as OrderEvent based on the simulation's rules and random factors.
 * 
 * @author Mohammad Minhaz Uddin
 */
class ArrivalEvent extends Event {
    private int groupLowerBound = 1;
    private int groupGeneratorBound = 4;

    /**
     * Constructs a new ArrivalEvent with a specified time of occurrence.
     * 
     * @param time the time at which the event occurs within the simulation
     */
    public ArrivalEvent(int time) {
        super(time);
    }

    /**
     * Processes the arrival by generating a random group size, attempting to seat the group,
     * and scheduling new events depending on the availability of seats.
     * 
     * @param sm the shop model used to manage shop state and interactions
     * @param s the simulator used to schedule future events in the simulation
     */
    @Override
    public void process(ShopModel sm, Simulator s) {
        Random random = Event.getGenerator();
        int numPeople = random.nextInt(groupGeneratorBound) + groupLowerBound; // Random group size 1 to 4
        int groupId = sm.getNextId();
        CustomerGroup group = new CustomerGroup(groupId, numPeople, getTime());

        if (sm.canSeat(getTime(), group)) {
            sm.addGroup(group);
            sm.logGroup(group);
            System.out.println("t = " + getTime() + ": Group " + groupId + " (" + numPeople + " people) seated");

            int orderTime = getTime() + random.nextInt(5) + 1; // 1 to 5 time units after arrival
            s.schedule(new OrderEvent(orderTime, group));
        } else {
            System.out.println("t = " + getTime() + ": Group " + groupId + " leaves due to insufficient seats");
            sm.incrementLostBusiness(numPeople);
        }

        int nextArrivalTime = getTime() + random.nextInt(6) + 2; // Randomize next arrival within logical range
        s.schedule(new ArrivalEvent(nextArrivalTime));
    }
}
