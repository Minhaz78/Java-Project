
package assignment1v2;

import java.util.ArrayList;
import java.util.List;

/**
 * Main class for the simulation of customer arrivals, seating, and service in an ice cream shop.
 * This class initializes the simulation environment, runs the simulation, and prints the results.
 * The simulation models customer group arrivals at an ice cream shop, handles seating availability,
 * processes orders, and tracks statistics such as customers served and lost business due to lack of space.
 * 
 * @author Mohammad Minhaz Uddin
 */
public class Assignment1V2 {
    
    /**
     * The main method sets up and executes the simulation.
     * It creates the shop model and the simulator, schedules initial events, runs the simulation,
     * and then displays results regarding groups in the shop, history/log of customer groups,
     * and overall simulation statistics.
     * 
     * @param args command line arguments (not used in this application)
     */
    public static void main(String[] args) {
        int numSeats = 8; // Number of seats available in the shop

        // Create a shop model with the specified number of seats
        ShopModel shopModel = new ShopModel(numSeats);

        // Create a simulator with the shop model
        Simulator simulator = new Simulator(shopModel);

        // Create a list of initial events
        List<Event> initialEvents = new ArrayList<>();
        initialEvents.add(new ArrivalEvent(0)); // First arrival event at time 0

        // Initialize the simulator with the initial events
        simulator.initialize(initialEvents);

        // Run the simulation for 20 time units
        simulator.run(20);

        // Display the groups in the shop
        System.out.println("\nGroups in the shop:");
        for (CustomerGroup group : shopModel.getGroupsInShop()) {
            System.out.println(group);
        }

        // Display the history/log of customer groups
        System.out.println("\nHistory/Log of Customer Groups:");
        for (CustomerGroup group : shopModel.getHistoryLog()) {
            System.out.println(group);
        }

        // Display simulation statistics
        System.out.println("\nSimulation Statistics:");
        System.out.println("Customers Served: " + shopModel.getNumServed());
        System.out.println("Lost Business: " + shopModel.getLostBusiness());
    }
}
