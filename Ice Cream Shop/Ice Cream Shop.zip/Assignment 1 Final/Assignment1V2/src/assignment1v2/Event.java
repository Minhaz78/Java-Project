package assignment1v2;

import java.util.Random;

/**
 * Abstract base class for events in the simulation.
 * This class provides the fundamental attributes and methods that all specific events must implement
 * and adhere to within the simulation. It includes a static random number generator initialized with
 * a fixed seed to ensure repeatable results in simulations for testing and debugging purposes.
 * 
 * @author Mohammad Minhaz Uddin
 */
abstract class Event {
    private int time;  // The simulation time at which this event should be processed.

    // Static random number generator with a seed to ensure consistent behavior across runs.
    private static Random generator = new Random(1);

    /**
     * Constructs a new event with a specified time.
     * 
     * @param time The simulation time at which the event occurs and is to be processed.
     */
    public Event(int time) {
        this.time = time;
    }

    /**
     * Returns the simulation time at which the event occurs.
     * 
     * @return The time of the event.
     */
    public int getTime() {
        return time;
    }

    /**
     * Provides access to the shared random number generator used by all events.
     * This method allows event implementations to generate deterministic random values
     * that are repeatable across different runs of the simulation.
     * 
     * @return The shared Random instance.
     */
    public static Random getGenerator() {
        return generator;
    }

    /**
     * Abstract method to process the event using the given shop model and simulator.
     * Each specific event type will implement this method to perform actions specific to the
     * event's context within the simulation, such as handling customer arrivals, orders, and departures.
     * 
     * @param sm The shop model on which the event will have an effect.
     * @param s The simulator that manages the queue of events and execution timing.
     */
    public abstract void process(ShopModel sm, Simulator s);
}
