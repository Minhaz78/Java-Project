

package assignment1v2;

/**
 * Represents the event of a customer group leaving the shop.
 * This event is scheduled when a group is ready to depart, following their completion
 * of activities within the shop (such as dining or receiving service). Processing this
 * event updates the shop's state to reflect the departure of the group, thereby freeing up resources.
 * 
 * @author Mohammad Minhaz Uddin
 */
class LeaveEvent extends Event {
    private CustomerGroup group;  // The customer group that is leaving the shop

    /**
     * Constructs a LeaveEvent with a specified time and the customer group that is leaving.
     * 
     * @param time The simulation time at which the group is scheduled to leave.
     * @param group The customer group that is leaving the shop.
     */
    public LeaveEvent(int time, CustomerGroup group) {
        super(time);
        this.group = group;
    }

    /**
     * Processes the leave event by removing the specified group from the shop.
     * This action is handled by the ShopModel, which updates its state to reflect
     * that the group no longer occupies space in the shop. This method is typically
     * called by the Simulator which manages the timeline of events.
     * 
     * @param sm The shop model that maintains the state of the shop and handles changes.
     * @param s The simulator that is managing the processing of events.
     */
    @Override
    public void process(ShopModel sm, Simulator s) {
        sm.leave(getTime(), group);
    }
}
