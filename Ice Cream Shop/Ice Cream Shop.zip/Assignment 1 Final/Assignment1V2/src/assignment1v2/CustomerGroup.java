package assignment1v2;

/**
 * Represents a group of customers arriving at the shop.
 * This class stores details about a customer group including their group ID,
 * number of people in the group, and the time of their arrival.
 * 
 * @author Mohammad Minhaz Uddin
 */
class CustomerGroup {
    private int groupId;       // Unique identifier for the customer group
    private int numPeople;     // Number of people in the customer group
    private int arrivalTime;   // Simulation time at which the group arrives

    /**
     * Constructs a new CustomerGroup with specified details.
     * 
     * @param groupId The unique identifier for the group.
     * @param numPeople The number of people in the group.
     * @param arrivalTime The simulation time at which the group arrives.
     */
    public CustomerGroup(int groupId, int numPeople, int arrivalTime) {
        this.groupId = groupId;
        this.numPeople = numPeople;
        this.arrivalTime = arrivalTime;
    }

    /**
     * Gets the group ID of the customer group.
     * 
     * @return The unique identifier for the group.
     */
    public int getGroupId() {
        return groupId;
    }

    /**
     * Gets the number of people in the customer group.
     * 
     * @return The number of people in the group.
     */
    public int getNumPeople() {
        return numPeople;
    }

    /**
     * Gets the arrival time of the customer group.
     * 
     * @return The simulation time at which the group arrived.
     */
    public int getArrivalTime() {
        return arrivalTime;
    }

    /**
     * Returns a string representation of the customer group, including the group ID,
     * number of people, and arrival time.
     * 
     * @return A string representation of the customer group.
     */
    @Override
    public String toString() {
        return String.format("Group %d (%d people) arrived at t = %d", groupId, numPeople, arrivalTime);
    }
}

