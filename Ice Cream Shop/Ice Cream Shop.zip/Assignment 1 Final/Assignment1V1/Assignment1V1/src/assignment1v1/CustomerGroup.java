/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1v1;

/**
 * Represents a group of customers that has arrived at the shop.
 *
 * @author Mohammad Minhaz Uddin
 */
class CustomerGroup {
    private int groupId;        // Unique identifier for the group
    private int numPeople;      // Number of people in the group
    private int arrivalTime;    // Time at which the group arrived

    /**
     * Constructs a new CustomerGroup.
     *
     * @param groupId     the unique identifier for the group
     * @param numPeople   the number of people in the group
     * @param arrivalTime the time at which the group arrived
     */
    public CustomerGroup(int groupId, int numPeople, int arrivalTime) {
        this.groupId = groupId;
        this.numPeople = numPeople;
        this.arrivalTime = arrivalTime;
    }

    /**
     * Gets the unique identifier of the group.
     *
     * @return the group identifier
     */
    public int getGroupId() {
        return groupId;
    }

    /**
     * Gets the number of people in the group.
     *
     * @return the number of people
     */
    public int getNumPeople() {
        return numPeople;
    }

    /**
     * Gets the arrival time of the group.
     *
     * @return the arrival time
     */
    public int getArrivalTime() {
        return arrivalTime;
    }

    /**
     * Returns a string representation of the CustomerGroup.
     *
     * @return a string representation of the CustomerGroup
     */
    @Override
    public String toString() {
        return "Group " + groupId + " (" + numPeople + " people) arrived at t = " + arrivalTime;
    }
}
