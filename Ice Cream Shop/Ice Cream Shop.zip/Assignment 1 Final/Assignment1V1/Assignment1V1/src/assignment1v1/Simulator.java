/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1v1;

/**
 * Represents the simulator for the discrete event simulation.
 * Implements the IScheduler interface to schedule events.
 * 
 * @author Mohammad Minhaz Uddin
 */
import java.util.ArrayList;
import java.util.List;

class Simulator implements IScheduler {
    private List<Event> events;  // The ordered list of events (event queue)
    private int clock;           // The simulation time
    private ShopModel model;     // The shop model representing the state of the shop

    /**
     * Constructs a new Simulator with the specified shop model.
     *
     * @param model the shop model
     */
    public Simulator(ShopModel model) {
        this.model = model;
        events = new ArrayList<>();
        clock = 0;
    }

    /**
     * Initializes the simulator with the initial events.
     *
     * @param initialEvents the initial events to add to the event queue
     */
    public void initialize(List<Event> initialEvents) {
        events.addAll(initialEvents);
    }

    /**
     * Runs the simulation until the specified stop time.
     *
     * @param stopTime the time at which to stop the simulation
     */
    public void run(int stopTime) {
        if (events == null || events.isEmpty())
            return;

        while (!events.isEmpty() && clock <= stopTime) {
            Event e = events.remove(0);
            clock = e.getTime();
            e.process(model, this);
        }
    }

    /**
     * Schedules an event in the event queue.
     * Maintains the event queue in sorted order of event times.
     *
     * @param e the event to be scheduled
     */
    @Override
    public void schedule(Event e) {
        int i = 0;
        while (i < events.size() && events.get(i).getTime() < e.getTime()) {
            i++;
        }
        events.add(i, e);
    }
}
