/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1v1;
/**
 * Represents an abstract event in the simulation.
 * Subclasses must implement the process method to define the behavior of the event.
 *
 * @author Mohammad Minhaz Uddin
 */
abstract class Event {
    private int time;  // The time at which the event occurs

    /**
     * Constructs a new Event with the specified time.
     *
     * @param time the time at which the event occurs
     */
    public Event(int time) {
        this.time = time;
    }

    /**
     * Gets the time at which the event occurs.
     *
     * @return the time of the event
     */
    public int getTime() {
        return time;
    }

    /**
     * Processes the event.
     * Subclasses must implement this method to define the behavior of the event.
     *
     * @param sm the shop model representing the state of the shop
     * @param s the scheduler used to schedule events
     */
    public abstract void process(ShopModel sm, IScheduler s);
}

