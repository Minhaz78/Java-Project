
package assignment1v1;

import java.util.ArrayList;
import java.util.List;

/**
 * Main class for running the simulation.
 *
 * @author Mohammad Minhaz Uddin
 */
public class Assignment1V1 {

    /**
     * Main method to initialize and run the simulation.
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Create a shop model
        ShopModel shopModel = new ShopModel();
        
        // Create a simulator with the shop model
        Simulator simulator = new Simulator(shopModel);

        // Create a list of initial events
        List<Event> initialEvents = new ArrayList<>();
        initialEvents.add(new ArrivalEvent(0)); // First arrival event at time 0

        // Initialize the simulator with the initial events
        simulator.initialize(initialEvents);
        
        // Run the simulation for 20 time units
        simulator.run(20); 

        // Display the groups in the shop
        System.out.println("\nGroups in the shop:");
        for (CustomerGroup group : shopModel.getGroupsInShop()) {
            System.out.println(group);
        }

        // Display the history/log of customer groups
        System.out.println("\nHistory/Log of Customer Groups:");
        for (CustomerGroup group : shopModel.getHistoryLog()) {
            System.out.println(group);
        }
    }
}

