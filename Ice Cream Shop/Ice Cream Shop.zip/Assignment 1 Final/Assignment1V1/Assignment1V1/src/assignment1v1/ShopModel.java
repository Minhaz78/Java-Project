/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1v1;

/**
 * Represents the model of the shop, including customer groups currently in the shop
 * and a history/log of customer groups.
 * 
 * @author Mohammad Minhaz Uddin
 */
import java.util.ArrayList;
import java.util.List;

class ShopModel {
    private List<CustomerGroup> groupsInShop; // List of customer groups currently in the shop
    private List<CustomerGroup> historyLog;  // List of all customer groups that have ever arrived
    private int nextIdentifier;               // Identifier for the next customer group

    /**
     * Constructs a new ShopModel.
     */
    public ShopModel() {
        groupsInShop = new ArrayList<>();
        historyLog = new ArrayList<>();
        nextIdentifier = 0;
    }

    /**
     * Gets the next unique identifier for a customer group.
     *
     * @return the next unique identifier
     */
    public int getNextId() {
        return nextIdentifier++;
    }

    /**
     * Adds a customer group to the list of groups currently in the shop.
     *
     * @param group the customer group to add
     */
    public void addGroup(CustomerGroup group) {
        groupsInShop.add(group);
    }

    /**
     * Logs a customer group to the history/log of customer groups.
     *
     * @param group the customer group to log
     */
    public void logGroup(CustomerGroup group) {
        historyLog.add(group);
    }

    /**
     * Gets the list of customer groups currently in the shop.
     *
     * @return the list of groups in the shop
     */
    public List<CustomerGroup> getGroupsInShop() {
        return groupsInShop;
    }

    /**
     * Gets the history/log of customer groups.
     *
     * @return the history/log of customer groups
     */
    public List<CustomerGroup> getHistoryLog() {
        return historyLog;
    }
}
