/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package assignment1v1;

/**
 * Defines the contract for a scheduler interface in the simulation.
 * Implementing classes must provide a method to schedule events.
 * 
 * @author Mohammad Minhaz Uddin
 */
interface IScheduler {
    /**
     * Schedules the specified event.
     * 
     * @param e the event to be scheduled
     */
    void schedule(Event e);
}

