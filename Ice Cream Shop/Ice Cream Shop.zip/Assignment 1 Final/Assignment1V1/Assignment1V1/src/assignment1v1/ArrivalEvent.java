/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1v1;

/**
 * Represents an arrival event where a group of customers arrives at the shop.
 * Extends the abstract Event class.
 *
 * @author Mohammad Minhaz Uddin
 */
class ArrivalEvent extends Event {
    /**
     * Constructs a new ArrivalEvent with the specified time.
     *
     * @param time the time at which the arrival event occurs
     */
    public ArrivalEvent(int time) {
        super(time);
    }

    /**
     * Processes the arrival event by creating a new CustomerGroup, adding it to the shop model,
     * logging the group, printing details of the arrival, and scheduling the next arrival event.
     *
     * @param sm the shop model representing the state of the shop
     * @param s the scheduler used to schedule events
     */
    @Override
    public void process(ShopModel sm, IScheduler s) {
        int groupId = sm.getNextId();
        CustomerGroup group = new CustomerGroup(groupId, 2, getTime());
        sm.addGroup(group);
        sm.logGroup(group);
        System.out.println("t = " + getTime() + ": " + group);

        // Schedule the next arrival event
        s.schedule(new ArrivalEvent(getTime() + 2));
    }
}


