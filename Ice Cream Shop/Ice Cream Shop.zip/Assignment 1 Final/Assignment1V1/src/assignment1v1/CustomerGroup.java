/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1v1;

/**
 * Represents a group of customers arriving at the shop.
 * Each group has an identifier, number of people, and arrival time.
 * @author Mohammad Minhaz Uddin
 */
public class CustomerGroup {
    private int id;
    private int numberInGroup;
    private int arrivalTime;

    /**
     * Constructs a CustomerGroup with the specified attributes.
     * @param id The identifier of the customer group.
     * @param numberInGroup The number of people in the group.
     * @param arrivalTime The arrival time of the group.
     */
    public CustomerGroup(int id, int numberInGroup, int arrivalTime) {
        this.id = id;
        this.numberInGroup = numberInGroup;
        this.arrivalTime = arrivalTime;
    }

    /**
     * Retrieves the identifier of the customer group.
     * @return The identifier of the group.
     */
    public int getId() {
        return id;
    }

    /**
     * Retrieves the number of people in the customer group.
     * @return The number of people in the group.
     */
    public int getNumberInGroup() {
        return numberInGroup;
    }

    /**
     * Retrieves the arrival time of the customer group.
     * @return The arrival time of the group.
     */
    public int getArrivalTime() {
        return arrivalTime;
    }

    /**
     * Provides a string representation of the customer group.
     * @return A string representing the customer group.
     */
    @Override
    public String toString() {
        return "Group " + id + " (" + numberInGroup + " people) arrived at t = " + arrivalTime;
    }
}
