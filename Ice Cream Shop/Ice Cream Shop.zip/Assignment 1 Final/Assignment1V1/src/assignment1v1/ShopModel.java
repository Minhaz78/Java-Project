package assignment1v1;

import java.util.ArrayList;
import java.util.Formatter;
import java.util.List;

/**
 * Represents the model of the shop.
 * Manages customer groups in the shop, tracks statistics, and logs history.
 * Implements methods to seat groups, handle group departures, and serve orders.
 * Also provides methods to retrieve statistical information and log data.
 * Additionally, it manages unique identifiers for customer groups.
 * This class facilitates the core functionality of the simulation system.
 * @author Mohammad Minhaz Uddin
 */
public class ShopModel {
    private List<CustomerGroup> groupsInShop = new ArrayList<>();
    private List<CustomerGroup> historyLog = new ArrayList<>();
    private int numSeats;
    private int lostBusiness = 0;
    private int numServed = 0;
    private int nextId = 0;  // Variable to track the next unique group ID

    /**
     * Constructs a ShopModel with the specified number of seats.
     * @param numSeats The total number of seats available in the shop.
     */
    public ShopModel(int numSeats) {
        this.numSeats = numSeats;
    }

    /**
     * Seats a customer group in the shop if sufficient seats are available.
     * Updates statistics and logs the group's arrival or loss.
     * @param group The customer group to be seated.
     */
    public void seatGroup(CustomerGroup group) {
        if (canSeat(group.getNumberInGroup())) {
            groupsInShop.add(group);
            numSeats -= group.getNumberInGroup();
            numServed += group.getNumberInGroup();
            System.out.println("t = " + group.getArrivalTime() + " : Group " + group.getId() + " (" + group.getNumberInGroup() + " people) seated");
        } else {
            lostBusiness += group.getNumberInGroup();
            System.out.println("t = " + group.getArrivalTime() + " : Group " + group.getId() + " leaves as there are insufficient seats for the group");
            historyLog.add(group);
        }
    }

    /**
     * Handles the departure of a customer group from the shop.
     * Updates the number of available seats.
     * @param time  The time at which the group leaves.
     * @param group The customer group leaving the shop.
     */
    public void leaveGroup(int time, CustomerGroup group) {
        groupsInShop.remove(group);
        numSeats += group.getNumberInGroup();
        System.out.println("t = " + time + ": Group " + group.getId() + " leaves");
    }

    /**
     * Checks if the shop can accommodate a group of a specified size.
     * @param numPeople The number of people in the group.
     * @return True if there are enough seats, false otherwise.
     */
    public boolean canSeat(int numPeople) {
        return numSeats >= numPeople;
    }

    /**
     * Retrieves the total number of customers who left due to insufficient seats.
     * @return The total number of customers who left due to insufficient seats.
     */
    public int getLostBusiness() {
        return lostBusiness;
    }

    /**
     * Retrieves the total number of customers served.
     * @return The total number of customers served.
     */
    public int getNumServed() {
        return numServed;
    }

    /**
     * Retrieves the list of customer groups currently in the shop.
     * @return The list of customer groups currently in the shop.
     */
    public List<CustomerGroup> getGroupsInShop() {
        return groupsInShop;
    }

    /**
     * Serves an order for a customer group at the specified time.
     * Prints a message indicating the order was served.
     * Additional logic related to order serving can be included here.
     * @param time  The time at which the order is served.
     * @param group The customer group whose order is served.
     */
    public void serveOrder(int time, CustomerGroup group) {
        System.out.println("t = " + time + ": Order served for Group " + group.getId());
        // You can include additional logic here, for instance updating statistics or states related to orders being served.
    }

    /**
     * Retrieves the history log of customer groups that have visited the shop.
     * @return The history log of customer groups.
     */
    public List<CustomerGroup> getHistoryLog() {
        return historyLog;
    }

    /**
     * Formats and writes the list of customer groups currently in the shop to the specified output.
     * @param output The formatter for writing output.
     */
    public void showGroups(Formatter output) {
        for (CustomerGroup group : groupsInShop) {
            output.format("%s%n", group.toString());
        }
    }

    /**
     * Formats and writes the history log of customer groups to the specified output.
     * @param output The formatter for writing output.
     */
    public void showLog(Formatter output) {
        for (CustomerGroup group : historyLog) {
            output.format("%s%n", group.toString());
        }
    }

    /**
     * Retrieves the next unique identifier for a customer group and increments the counter.
     * @return The next unique identifier for a customer group.
     */
    public int getNextId() {
        return nextId++;
    }
}
