package assignment1v1;


/**
 * Represents an event where a customer group arrives at the shop.
 * This class extends the Event class and implements methods to process arrival events.
 * @author Mohammad Minhaz Uddin
 */
public class ArrivalEvent extends Event {
    private int groupLowerBound;
    private int groupUpperBound;

    /**
     * Constructs an ArrivalEvent with the specified time and group size bounds.
     *
     * @param time           The time at which the arrival event occurs.
     * @param groupLowerBound The lower bound of the group size arriving.
     * @param groupUpperBound The upper bound of the group size arriving.
     */
    public ArrivalEvent(int time, int groupLowerBound, int groupUpperBound) {
        super(time);
        this.groupLowerBound = groupLowerBound;
        this.groupUpperBound = groupUpperBound;
    }

    /**
     * Processes the arrival event by creating a customer group, seating it in the shop, and scheduling an order event if possible.
     *
     * @param shopModel  The shop model in which the event occurs.
     * @param scheduler  The scheduler responsible for scheduling events.
     */
    @Override
    public void process(ShopModel shopModel, IScheduler scheduler) {
        int numPeople = (int) (Math.random() * (groupUpperBound - groupLowerBound + 1) + groupLowerBound);
        CustomerGroup group = new CustomerGroup(shopModel.getNextId(), numPeople, getTime());
        shopModel.seatGroup(group);
        if (shopModel.canSeat(numPeople)) {
            scheduler.schedule(new OrderEvent(getTime() + 1, group));  // Assuming immediate processing
        }
        // Schedule the next arrival with similar or new bounds as needed
        scheduler.schedule(new ArrivalEvent(getTime() + (int) (Math.random() * 5 + 1), groupLowerBound, groupUpperBound));
    }
}

