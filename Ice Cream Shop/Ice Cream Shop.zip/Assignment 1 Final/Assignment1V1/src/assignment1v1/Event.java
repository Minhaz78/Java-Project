
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1v1;

/**
 * Represents an abstract event in the simulation.
 * Each event has a specific time at which it occurs.
 * Subclasses of Event must implement the process method.
 * @author Mohammad Minhaz Uddin
 */
public abstract class Event {
    private int time;

    /**
     * Constructs an Event with the specified time.
     * @param time The time at which the event occurs.
     */
    public Event(int time) {
        this.time = time;
    }

    /**
     * Retrieves the time at which the event occurs.
     * @return The time of the event.
     */
    public int getTime() {
        return time;
    }

    /**
     * Processes the event within the given shop model and scheduler.
     * Subclasses must implement this method.
     * @param shopModel The shop model in which the event occurs.
     * @param scheduler The scheduler responsible for scheduling events.
     */
    public abstract void process(ShopModel shopModel, IScheduler scheduler);
}
