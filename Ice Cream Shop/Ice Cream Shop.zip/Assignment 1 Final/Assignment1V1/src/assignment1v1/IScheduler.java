
package assignment1v1;

/**
 * Defines the interface for a scheduler responsible for scheduling events.
 * Implementations of this interface must provide a method to schedule events.
 * This interface enables decoupling between event scheduling logic and the rest of the system.
 * @author Mohammad Minhaz Uddin
 */
public interface IScheduler {
    /**
     * Schedules the given event.
     * @param event The event to be scheduled.
     */
    void schedule(Event event);
}

