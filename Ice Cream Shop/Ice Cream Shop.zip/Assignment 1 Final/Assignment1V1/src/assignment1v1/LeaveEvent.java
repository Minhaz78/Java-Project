package assignment1v1;

/**
 * Represents an event where a customer group leaves the shop.
 * This event occurs when a customer group finishes their visit to the shop.
 * @author Mohammad Minhaz Uddin
 */
public class LeaveEvent extends Event {
    private CustomerGroup group;

    /**
     * Constructs a LeaveEvent with the specified time and customer group.
     * @param time  The time at which the leave event occurs.
     * @param group The customer group leaving the shop.
     */
    public LeaveEvent(int time, CustomerGroup group) {
        super(time);
        this.group = group;
    }

    /**
     * Processes the leave event by removing the customer group from the shop model.
     * @param shopModel The shop model in which the event occurs.
     * @param scheduler The scheduler responsible for scheduling events.
     */
    @Override
    public void process(ShopModel shopModel, IScheduler scheduler) {
        shopModel.leaveGroup(getTime(), group);
    }
}
