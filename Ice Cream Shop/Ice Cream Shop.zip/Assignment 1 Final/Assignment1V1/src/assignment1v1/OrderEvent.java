/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1v1;

/**
 * Represents an event where a customer group places an order in the shop.
 * This event occurs when a customer group is ready to place their order.
 * Optionally, it schedules a LeaveEvent to remove the group after a fixed amount of time.
 * @author Mohammad Minhaz Uddin
 */
public class OrderEvent extends Event {
    private CustomerGroup group;

    /**
     * Constructs an OrderEvent with the specified time and customer group.
     * @param time  The time at which the order event occurs.
     * @param group The customer group placing the order.
     */
    public OrderEvent(int time, CustomerGroup group) {
        super(time);
        this.group = group;
    }

    /**
     * Processes the order event by serving the order for the customer group.
     * Optionally, schedules a LeaveEvent to remove the group after a fixed amount of time.
     * @param shopModel The shop model in which the event occurs.
     * @param scheduler The scheduler responsible for scheduling events.
     */
    @Override
    public void process(ShopModel shopModel, IScheduler scheduler) {
        shopModel.serveOrder(getTime(), group);
        // If you want the group to leave after a fixed amount of time:
        scheduler.schedule(new LeaveEvent(getTime() + 10, group));
    }
}
