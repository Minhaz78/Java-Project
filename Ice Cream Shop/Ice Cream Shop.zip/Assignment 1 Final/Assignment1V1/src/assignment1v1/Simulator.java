package assignment1v1;

import java.util.PriorityQueue;
import java.util.Comparator;

/**
 * Represents the simulator for the shop's event-driven simulation.
 * Manages the event queue and controls the flow of the simulation.
 * Implements the IScheduler interface for event scheduling.
 * This class orchestrates the execution of events in the simulation system.
 * It processes events in order of their scheduled time.
 * @author Mohammad Minhaz Uddin
 */
public class Simulator implements IScheduler {
    private PriorityQueue<Event> eventQueue = new PriorityQueue<>(Comparator.comparingInt(Event::getTime));
    private ShopModel model;

    /**
     * Constructs a Simulator with the specified shop model.
     * @param model The shop model to be simulated.
     */
    public Simulator(ShopModel model) {
        this.model = model;
    }

    /**
     * Runs the simulation until the specified stop time is reached.
     * Processes events in the event queue until it's empty or reaches the stop time.
     * @param stopTime The time at which the simulation should stop.
     */
    public void runSimulation(int stopTime) {
        while (!eventQueue.isEmpty()) {
            Event currentEvent = eventQueue.poll();
            if (currentEvent.getTime() <= stopTime) {
                currentEvent.process(model, this);
            }
        }
    }

    /**
     * Schedules an event by adding it to the event queue.
     * @param event The event to be scheduled.
     */
    @Override
    public void schedule(Event event) {
        eventQueue.add(event);
    }
}
