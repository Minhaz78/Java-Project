package assignment1v1;


import java.util.Formatter;

/**
 * Represents the main class for Assignment 1 Version 1.
 * This class contains the main method to execute the simulation and output the results.
 * @author Mohammad Minhaz Uddin
 */
public class Assignment1V1 {
    /**
     * Main method to execute the simulation and output the results.
     * @param args The command line arguments.
     */
    public static void main(String[] args) {
        int numSeats = 8;
        ShopModel shopModel = new ShopModel(numSeats);
        Simulator simulator = new Simulator(shopModel);

        simulator.schedule(new ArrivalEvent(0, 1, 5));
        simulator.runSimulation(20);

        // Output to the console
        System.out.println("\nCustomers Served: " + shopModel.getNumServed());
        System.out.println("Lost Business: " + shopModel.getLostBusiness());
        System.out.println("\nGroups still in the shop:");
        shopModel.getGroupsInShop().forEach(System.out::println);
        System.out.println("\nHistory/Log of Customer Groups:");
        shopModel.getHistoryLog().forEach(System.out::println);

        // Output to a file
        try (Formatter output = new Formatter("statistics.txt")) {
            output.format("Customers Served: %d%n", shopModel.getNumServed());
            output.format("Lost Business: %d%n", shopModel.getLostBusiness());
            output.format("%nGroups still in the shop:%n");
            shopModel.showGroups(output);
            output.format("%nHistory/Log of Customer Groups:%n");
            shopModel.showLog(output);
        } catch (Exception e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }
    }
}
