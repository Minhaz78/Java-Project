package cqu.huffmancodes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.PriorityQueue;

/**
 * Represents the Huffman tree used for encoding and decoding operations.
 * The Huffman tree is constructed from character frequencies and used to generate
 * Huffman codes for efficient data compression.
 * This class provides methods to encode text, decode encoded text, save the tree to a file,
 * and load the tree from a file.
 * 
 * @authored Mohammad Minhaz Uddin
 */
public class HuffmanTree {
    public static final int NCHARS = 128;
    private Node root;
    private String[] codeTable = new String[NCHARS];
    private int[] frequencyTable = new int[NCHARS];
    private PriorityQueue<Node> priorityQ;
    private String plainText;

    /**
     * Constructs a HuffmanTree from the given plain text.
     * 
     * @param plainText The plain text to be encoded.
     */
    public HuffmanTree(String plainText) {
        this.plainText = plainText;
        this.root = createCodeTree();
        generateCodes(root, new StringBuffer());
    }

    /**
     * Default constructor. Initializes the root to null.
     */
    public HuffmanTree() {
        this.root = null;
    }

    public int[] getFrequencyTable() {
        return frequencyTable;
    }

    public String[] getCodeTable() {
        return codeTable;
    }

    private Node createCodeTree() {
        for (char ch : plainText.toCharArray()) {
            frequencyTable[ch]++;
        }

        priorityQ = new PriorityQueue<>();
        for (int i = 0; i < NCHARS; i++) {
            if (frequencyTable[i] > 0) {
                priorityQ.add(new Node((char) i, frequencyTable[i]));
            }
        }

        while (priorityQ.size() > 1) {
            Node left = priorityQ.poll();
            Node right = priorityQ.poll();
            Node parent = new Node(left, right);
            priorityQ.add(parent);
        }

        return priorityQ.poll();
    }

    private void generateCodes(Node node, StringBuffer code) {
        if (node != null) {
            if (node.isLeaf()) {
                codeTable[node.getCh()] = code.toString();
            } else {
                code.append('0');
                generateCodes(node.getLeft(), code);
                code.deleteCharAt(code.length() - 1);

                code.append('1');
                generateCodes(node.getRight(), code);
                code.deleteCharAt(code.length() - 1);
            }
        }
    }

    /**
     * Encodes the given text using the Huffman codes.
     * 
     * @param text The text to be encoded.
     * @return The encoded text as a string.
     */
    public String encode(String text) {
        StringBuilder encodedText = new StringBuilder();
        for (char ch : text.toCharArray()) {
            encodedText.append(codeTable[ch]);
        }
        return encodedText.toString();
    }

    /**
     * Decodes the given encoded text using the Huffman tree.
     * 
     * @param encodedText The encoded text to be decoded.
     * @return The decoded text as a string.
     */
    public String decode(String encodedText) {
        StringBuilder decodedText = new StringBuilder();
        Node currentNode = root;

        for (char bit : encodedText.toCharArray()) {
            currentNode = (bit == '0') ? currentNode.getLeft() : currentNode.getRight();

            if (currentNode.isLeaf()) {
                decodedText.append(currentNode.getCh());
                currentNode = root;
            }
        }

        return decodedText.toString();
    }

    /**
     * Saves the Huffman tree to a file.
     * 
     * @param fname The name of the file.
     */
    public void save(String fname) {
        try (Formatter formatter = new Formatter(new FileWriter(fname))) {
            label(root, 1);
            save(root, formatter);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void save(Node node, Formatter f) {
        if (node != null) {
            f.format("%d %s %d%n", node.label, node.getCharacterAsString(), node.getFrequency());
            save(node.left, f);
            save(node.right, f);
        }
    }

    private int label(Node n, int count) {
        if (n != null) {
            int next = label(n.left, count);
            n.label = next++;
            next = label(n.right, next);
            return next;
        }
        return count;
    }

    /**
     * Loads the Huffman tree from a file.
     * 
     * @param fname The name of the file.
     */
    public void load(String fname) {
        try (BufferedReader br = new BufferedReader(new FileReader(fname))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(" ");
                int label = Integer.parseInt(parts[0]);
                String chString = parts[1];
                int frequency = Integer.parseInt(parts[2]);
                Node newNode = new Node(label, chString, frequency);
                insert(newNode);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void insert(Node newNode) {
        if (root == null) {
            root = newNode;
        } else {
            insertRec(root, newNode);
        }
    }

    private void insertRec(Node current, Node newNode) {
        if (newNode.label < current.label) {
            if (current.left == null) {
                current.left = newNode;
            } else {
                insertRec(current.left, newNode);
            }
        } else {
            if (current.right == null) {
                current.right = newNode;
            } else {
                insertRec(current.right, newNode);
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        toString(0, "root:", root, sb);
        return sb.toString();
    }

    private void toString(int level, String n, Node node, StringBuilder sb) {
        if (node == null) {
            return;
        }

        level = level + 2;
        for (int i = 0; i < level; i++) {
            sb.append(" ");
        }

        sb.append(String.format("%s %s %n", n, node));
        toString(level, "left: ", node.getLeft(), sb);
        toString(level, "right:", node.getRight(), sb);
    }
}

