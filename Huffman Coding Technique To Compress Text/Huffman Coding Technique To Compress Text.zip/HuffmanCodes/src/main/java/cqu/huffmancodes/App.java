package cqu.huffmancodes;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

/**
 * Main class for the Huffman Encoding application.
 * @authored Mohammad Minhaz Uddin
 */
public class App extends Application {
    
    /**
     * The main scene of the application.
     */
    private static Scene scene;

    /**
     * Launches the application.
     *
     * @param args The command-line arguments.
     */
    public static void main(String[] args) {
        launch();
    }

    /**
     * Sets the root FXML file for the scene.
     *
     * @param fxml The name of the FXML file.
     * @throws IOException If an error occurs while loading the FXML file.
     */
    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    /**
     * Loads the FXML file and returns its root element.
     *
     * @param fxml The name of the FXML file.
     * @return The root element of the loaded FXML file.
     * @throws IOException If an error occurs while loading the FXML file.
     */
    private static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    /**
     * Starts the JavaFX application.
     *
     * @param stage The primary stage of the application.
     * @throws IOException If an error occurs while starting the application.
     */
    @Override
    public void start(Stage stage) throws IOException {
        scene = new Scene(loadFXML("FXMLDocument"), 900, 400);
        stage.setScene(scene);
        stage.setTitle("Huffman Encoding");
        stage.show();
    }
}
