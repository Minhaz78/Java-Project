package cqu.huffmancodes;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * Controller class for the Huffman encoding/decoding application.
 * This class handles user interactions with the GUI, encoding and decoding text,
 * and saving/loading the Huffman tree.
 * 
 * @author Mohammad Minhaz Uddin
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private TextArea plainTextArea;

    @FXML
    private TextArea outputTextArea;

    @FXML
    private TextArea encodedTextArea;

    @FXML
    private Button encodeButton;

    @FXML
    private Button decodeButton;

    @FXML
    private Button displayFreqButton;

    @FXML
    private Button saveHuffmanTreeButton;

    @FXML
    private Button loadHuffmanTreeButton;

    @FXML
    private Button displayHuffmanCodesButton;

    @FXML
    private Button displayHuffmanTreeButton;

    @FXML
    private Button exitButton;

    private HuffmanTree huffmanTree;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        displayHuffmanTreeButton.setOnAction(event -> handleDisplayHuffmanTreeButtonAction(event));
        displayHuffmanCodesButton.setOnAction(event -> handleDisplayHuffmanCodesButtonAction(event));
    }

    /**
     * Handles the action of encoding text.
     * 
     * @param event The action event.
     */
    public void handleEncodeButtonAction(ActionEvent event) {
        String plainText = plainTextArea.getText();
        if (plainText.isEmpty()) {
            outputTextArea.setText("Please enter a plain text string to encode.");
            return;
        }
        huffmanTree = new HuffmanTree(plainText);
        String encodedText = huffmanTree.encode(plainText);
        encodedTextArea.setText(encodedText);
        outputTextArea.setText("Encoding complete.");
        plainTextArea.clear();
    }

    /**
     * Handles the action of decoding text.
     * 
     * @param event The action event.
     */
    public void handleDecodeButtonAction(ActionEvent event) {
        String encodedText = encodedTextArea.getText();
        if (encodedText.isEmpty()) {
            outputTextArea.setText("No encoded message found.");
            return;
        }
        if (huffmanTree == null) {
            outputTextArea.setText("No Huffman tree available for decoding.");
            return;
        }
        String decodedText = huffmanTree.decode(encodedText);
        plainTextArea.setText(decodedText);
        outputTextArea.setText("Decoding complete.");
        encodedTextArea.clear();
    }

    /**
     * Handles the action of displaying character frequencies.
     * 
     * @param event The action event.
     */
    public void handleDisplayFreqButtonAction(ActionEvent event) {
        if (huffmanTree == null) {
            outputTextArea.setText("Please encode text first.");
            return;
        }
        int[] freqTable = huffmanTree.getFrequencyTable();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < freqTable.length; i++) {
            if (freqTable[i] > 0) {
                sb.append((char) i).append(": ").append(freqTable[i]).append("\n");
            }
        }
        outputTextArea.setText(sb.toString());
    }

    /**
     * Handles the action of saving the Huffman tree to a file.
     * 
     * @param event The action event.
     */
    public void handleSaveHuffmanTreeButtonAction(ActionEvent event) {
        if (huffmanTree == null) {
            outputTextArea.setText("Huffman tree is not initialized.");
            return;
        }

        try {
            huffmanTree.save("tree.txt");
            outputTextArea.setText("Tree successfully saved to file");
        } catch (Exception e) {
            outputTextArea.setText("Error saving tree to file: " + e.getMessage());
        }
    }

    /**
     * Handles the action of loading the Huffman tree from a file.
     * 
     * @param event The action event.
     */
    public void handleLoadHuffmanTreeButtonAction(ActionEvent event) {
        huffmanTree = new HuffmanTree();
        try {
            huffmanTree.load("tree.txt");
            outputTextArea.setText("Tree successfully loaded from file");
        } catch (Exception e) {
            outputTextArea.setText("Error loading tree from file: " + e.getMessage());
        }
    }

    /**
     * Handles the action of displaying Huffman codes.
     * 
     * @param event The action event.
     */
    public void handleDisplayHuffmanCodesButtonAction(ActionEvent event) {
        if (huffmanTree == null) {
            outputTextArea.setText("Please encode text first.");
            return;
        }
        String[] codeTable = huffmanTree.getCodeTable();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < codeTable.length; i++) {
            if (codeTable[i] != null) {
                sb.append((char) i).append(": ").append(codeTable[i]).append("\n");
            }
        }
        outputTextArea.setText(sb.toString());
    }

    /**
     * Handles the action of displaying the Huffman tree structure.
     * 
     * @param event The action event.
     */
    public void handleDisplayHuffmanTreeButtonAction(ActionEvent event) {
        if (huffmanTree != null) {
            outputTextArea.setText(huffmanTree.toString());
        } else {
            outputTextArea.setText("Huffman tree is not initialized.");
        }
    }

    /**
     * Handles the action of exiting the application.
     * 
     * @param event The action event.
     */
    public void handleExitButtonAction(ActionEvent event) {
        exitButton.getScene().getWindow().hide();
    }
}

