package cqu.huffmancodes;

/**
 * Represents a node in the Huffman tree.
 * This class is used to construct the Huffman tree for encoding and decoding operations.
 * Each node stores a character, its frequency, and references to its left and right children.
 * It also supports creation from a line in a text file for reconstruction of the tree.
 * 
 * @author Mohammad Minhaz Uddin
 */
public class Node implements Comparable<Node> {
    public int label;
    private char ch;
    private int frequency;
    Node left, right;

    /**
     * Constructor for leaf nodes.
     * 
     * @param ch The character stored in the node.
     * @param frequency The frequency of the character.
     */
    public Node(char ch, int frequency) {
        this.ch = ch;
        this.frequency = frequency;
        this.left = null;
        this.right = null;
    }

    /**
     * Constructor for internal nodes.
     * 
     * @param left The left child node.
     * @param right The right child node.
     */
    public Node(Node left, Node right) {
        this.left = left;
        this.right = right;
        this.frequency = left.frequency + right.frequency;
    }

    /**
     * Constructor to create a node from a line in a text file.
     * 
     * @param label The label of the node.
     * @param s The string representation of the character.
     * @param frequency The frequency of the character.
     */
    public Node(int label, String s, int frequency) {
        this.label = label;
        this.frequency = frequency;
        this.left = null;
        this.right = null;
        if (s.equals("none")) {
            this.ch = '\0';
        } else if (s.equals("space")) {
            this.ch = ' ';
        } else {
            this.ch = s.charAt(0);
        }
    }

    /**
     * Checks if the node is a leaf node.
     * 
     * @return True if the node is a leaf node, false otherwise.
     */
    public boolean isLeaf() {
        return left == null && right == null;
    }

    public char getCh() {
        return ch;
    }

    public Node getLeft() {
        return left;
    }

    public Node getRight() {
        return right;
    }

    public int getFrequency() {
        return frequency;
    }

    /**
     * Returns a string representation of the character stored in the node.
     * 
     * @return "none" if the character is null, "space" if the character is a space,
     *         otherwise the character as a string.
     */
    public String getCharacterAsString() {
        if (ch == '\0') {
            return "none";
        } else if (ch == ' ') {
            return "space";
        } else {
            return Character.toString(ch);
        }
    }

    @Override
    public int compareTo(Node other) {
        return Integer.compare(this.frequency, other.frequency);
    }

    @Override
    public String toString() {
        if (isLeaf()) {
            return String.format("'%c' (%d)", ch, frequency);
        } else {
            return String.format("(%d)", frequency);
        }
    }
}
