module cqu.huffmancodes {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens cqu.huffmancodes to javafx.fxml;
    exports cqu.huffmancodes;
}
