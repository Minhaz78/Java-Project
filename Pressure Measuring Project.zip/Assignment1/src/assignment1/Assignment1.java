package assignment1;

import java.util.Scanner;

public class Assignment1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the MAP Calculator App!");

        System.out.print("Enter the number of BMI calculations to be performed: ");
        int numCalculations = scanner.nextInt();

        if (numCalculations <= 0) {
            System.out.println("Invalid number of data items. Exiting...");
            System.exit(0);
        }

        MAPCalculatorApp mapCalculator = new MAPCalculatorApp();

        double sumMap = 0;
        double maxMap = Double.MIN_VALUE;
        double minMap = Double.MAX_VALUE;
        int highLowCount = 0;

        for (int i = 0; i < numCalculations; i++) {
System.out.println("Enter the patient id SBP DBP after the prompt (>)");
            int identifier = scanner.nextInt();
            int sbp = scanner.nextInt();
            int dbp = scanner.nextInt();




            if (sbp <= dbp) {
                System.out.println("Invalid blood pressure values for person #" + identifier + ". SBP must be greater than DBP.");
                continue;
            }

            double map = mapCalculator.calculateMAP(sbp, dbp);
            sumMap += map;
            maxMap = Math.max(maxMap, map);
            minMap = Math.min(minMap, map);



            String mapCategory = mapCalculator.categorise(map);

            System.out.println("Person #" + identifier + " MAP: " +  String.format("%.2f", map)+ " (" + mapCategory + ")");

            if (map < 70 || map > 100) {
                highLowCount++;
            }
        }

        double averageMap = sumMap / numCalculations;

        System.out.println("\nSummary Statistics:");
        System.out.println("==================");
        System.out.println("Lowest MAP value: " +  String.format("%.1f", minMap));
        System.out.println("Highest MAP value: " +  String.format("%.1f", maxMap));
        System.out.println("Average MAP value: "+  String.format("%.1f", averageMap) );
        System.out.println("Number too high or too low : " + highLowCount);

        System.out.println("\nThank you for using the MAP Calculator App!");

        scanner.close();
    }
}
