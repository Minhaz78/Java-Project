package assignment1;

class MAPCalculatorApp {
    

    public double calculateMAP(double sbp, double dbp) {
        return (1.0 / 3.0) * sbp + (2.0 / 3.0) * dbp;
    }

    public String categorise(double map) {
        if (map > 100) {
            return "High";
        } else if (map < 70) {
            return "Low";
        } else {
            return "Normal";
        }
    }
}
